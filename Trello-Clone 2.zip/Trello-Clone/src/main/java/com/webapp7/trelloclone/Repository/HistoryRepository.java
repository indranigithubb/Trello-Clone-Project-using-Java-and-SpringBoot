package com.webapp7.trelloclone.Repository;

import com.webapp7.trelloclone.Model.History;
import org.springframework.data.repository.CrudRepository;

public interface HistoryRepository extends CrudRepository<History, Long> {
}
