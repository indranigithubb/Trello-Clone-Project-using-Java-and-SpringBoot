package com.webapp7.trelloclone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrelloCloneApplicationTests {

    @Test
    void contextLoads() {
    }

}
